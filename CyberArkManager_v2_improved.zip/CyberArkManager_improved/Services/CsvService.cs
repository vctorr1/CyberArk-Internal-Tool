using System.Globalization;
using System.IO;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;
using CyberArkManager.Models;

namespace CyberArkManager.Services;

public class CsvService
{
    private static readonly string[] Headers =
    {
        "Safe Name","Platform ID","Address","User Name","Password",
        "Account Description","Enable Automatic Management","Manual Management Reason",
        "Group Name","Group Platform ID","Remote Machines"
    };

    public async Task ExportAsync(IEnumerable<CsvAccountRow> rows, string filePath, CancellationToken ct = default)
    {
        await using var w = new StreamWriter(filePath, false, new UTF8Encoding(true));
        var cfg = new CsvConfiguration(CultureInfo.InvariantCulture) { HasHeaderRecord = true };
        await using var csv = new CsvWriter(w, cfg);

        foreach (var h in Headers) csv.WriteField(h);
        await csv.NextRecordAsync();

        foreach (var r in rows)
        {
            ct.ThrowIfCancellationRequested();
            csv.WriteField(r.SafeName);
            csv.WriteField(r.PlatformId);
            csv.WriteField(r.Address);
            csv.WriteField(r.UserName);
            csv.WriteField(r.Password ?? "");
            csv.WriteField(r.Description ?? "");
            csv.WriteField(r.AutoManagement ? "Yes" : "No");
            csv.WriteField(r.ManualReason ?? "");
            csv.WriteField(r.GroupName ?? "");
            csv.WriteField(r.GroupPlatformId ?? "");
            csv.WriteField(r.RemoteMachines ?? "");
            await csv.NextRecordAsync();
        }
    }

    public async Task ExportEmptyTemplateAsync(string filePath, CancellationToken ct = default)
        => await ExportAsync(Array.Empty<CsvAccountRow>(), filePath, ct);

    public async Task<List<CsvAccountRow>> ImportAsync(string filePath, CancellationToken ct = default)
    {
        var rows = new List<CsvAccountRow>();
        using var rdr = new StreamReader(filePath, Encoding.UTF8);
        var cfg = new CsvConfiguration(CultureInfo.InvariantCulture) { HasHeaderRecord = true, MissingFieldFound = null, HeaderValidated = null };
        using var csv = new CsvReader(rdr, cfg);
        await csv.ReadAsync(); csv.ReadHeader();
        while (await csv.ReadAsync())
        {
            ct.ThrowIfCancellationRequested();
            rows.Add(new CsvAccountRow
            {
                SafeName       = csv.GetField("Safe Name")       ?? "",
                PlatformId     = csv.GetField("Platform ID")      ?? "",
                Address        = csv.GetField("Address")          ?? "",
                UserName       = csv.GetField("User Name")        ?? "",
                Password       = csv.GetField("Password"),
                Description    = csv.GetField("Account Description"),
                AutoManagement = (csv.GetField("Enable Automatic Management") ?? "Yes").Equals("Yes", StringComparison.OrdinalIgnoreCase),
                ManualReason   = csv.GetField("Manual Management Reason"),
                GroupName      = csv.GetField("Group Name"),
                GroupPlatformId = csv.GetField("Group Platform ID"),
                RemoteMachines = csv.GetField("Remote Machines")
            });
        }
        return rows;
    }

    public static List<AccountCreateRequest> ToApiRequests(IEnumerable<CsvAccountRow> rows)
        => rows.Select(r => new AccountCreateRequest
        {
            Address    = r.Address,
            UserName   = r.UserName,
            PlatformId = r.PlatformId,
            SafeName   = r.SafeName,
            Secret     = string.IsNullOrEmpty(r.Password) ? null : r.Password,
            SecretType = "password",
            SecretManagement = new SecretManagementRequest
            {
                AutomaticManagementEnabled = r.AutoManagement,
                ManualManagementReason     = r.AutoManagement ? null : r.ManualReason
            }
        }).ToList();

    public static List<string> Validate(IEnumerable<CsvAccountRow> rows)
    {
        var errors = new List<string>();
        int i = 1;
        foreach (var r in rows)
        {
            if (string.IsNullOrWhiteSpace(r.SafeName))   errors.Add($"Fila {i}: Safe Name obligatorio.");
            if (string.IsNullOrWhiteSpace(r.PlatformId)) errors.Add($"Fila {i}: Platform ID obligatorio.");
            if (string.IsNullOrWhiteSpace(r.Address))    errors.Add($"Fila {i}: Address obligatorio.");
            if (string.IsNullOrWhiteSpace(r.UserName))   errors.Add($"Fila {i}: User Name obligatorio.");
            i++;
        }
        return errors;
    }
}
