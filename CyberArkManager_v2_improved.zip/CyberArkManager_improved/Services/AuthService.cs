using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Timers;
using CyberArkManager.Models;
using Serilog;

namespace CyberArkManager.Services;

/// <summary>
/// Manages CyberArk authentication sessions.
/// Security: passwords are stored as SecureString and cleared from memory after use.
/// Sessions have an explicit hard expiry (default 8 h) independent of heartbeat.
/// </summary>
public class AuthService : IDisposable
{
    // ── Public events ──────────────────────────────────────────────────────
    public event EventHandler<string>? StatusMessage;
    public event EventHandler<string>? SessionRenewed;
    public event EventHandler?         SessionExpired;

    // ── Constants ──────────────────────────────────────────────────────────
    private const int MaxConsecutiveFailures = 3;
    private const int HardSessionTimeoutHours = 8;          // absolute session ceiling
    private static readonly TimeSpan HttpTimeout = TimeSpan.FromSeconds(30);

    // ── Private state ──────────────────────────────────────────────────────
    private readonly HttpClient _http;
    private System.Timers.Timer? _heartbeatTimer;
    private System.Timers.Timer? _hardExpiryTimer;
    private UserSession? _session;

    /// <summary>
    /// Password kept as SecureString — never stored as plain string after login.
    /// Null when using Windows auth (no re-login needed) or after session close.
    /// </summary>
    private SecureString? _securePassword;

    private string? _authMethod;
    private int _consecutiveFailures;
    private bool _disposed;

    private static readonly ILogger _log = Log.ForContext<AuthService>();

    public AuthService(HttpClient http) => _http = http;

    public UserSession? CurrentSession => _session?.IsActive == true ? _session : null;

    // ── Auth Methods ───────────────────────────────────────────────────────

    /// <summary>Login CyberArk native, LDAP, RADIUS o Windows.</summary>
    public async Task<UserSession> LoginAsync(
        string pvwaUrl, string username, string password,
        string authMethod = "CyberArk", int heartbeatMin = 10,
        CancellationToken ct = default)
    {
        var base_ = NormalizeUrl(pvwaUrl);
        _log.Information("Login attempt. User={User} Method={Method} Url={Url}", username, authMethod, base_);

        var token = await FetchTokenAsync(base_, username, password, authMethod, ct);

        // Store password as SecureString — wipe the plain string from managed heap ASAP
        ClearSecurePassword();
        _securePassword = ToSecureString(password);
        _authMethod     = authMethod;
        _consecutiveFailures = 0;

        _session = new UserSession
        {
            Token     = token,
            Username  = username,
            PvwaUrl   = base_,
            LoginTime = DateTime.Now,
            LastRenew = DateTime.Now,
            HardExpiry = DateTime.Now.AddHours(HardSessionTimeoutHours)
        };

        ApplyToken(token);
        StartTimers(heartbeatMin);

        _log.Information("Session started. User={User} HardExpiry={Expiry}", username, _session.HardExpiry);
        StatusMessage?.Invoke(this, $"✔ Sesión iniciada · {username} · keep-alive cada {heartbeatMin} min (expira en {HardSessionTimeoutHours}h)");
        return _session;
    }

    /// <summary>Windows Integrated Auth (no password needed).</summary>
    public async Task<UserSession> LoginWindowsAsync(string pvwaUrl, int heartbeatMin = 10, CancellationToken ct = default)
    {
        var base_ = NormalizeUrl(pvwaUrl);
        _log.Information("Windows auth attempt. Url={Url}", base_);

        var url  = $"{base_}/API/auth/Windows/Logon";
        var resp = await _http.PostAsync(url, null, ct);
        await EnsureOk(resp, ct);
        var token = (await resp.Content.ReadAsStringAsync(ct)).Trim('"');

        // Windows SSO — no password to cache
        ClearSecurePassword();
        _authMethod = "Windows";
        _consecutiveFailures = 0;

        _session = new UserSession
        {
            Token     = token,
            Username  = Environment.UserName,
            PvwaUrl   = base_,
            LoginTime = DateTime.Now,
            LastRenew = DateTime.Now,
            HardExpiry = DateTime.Now.AddHours(HardSessionTimeoutHours)
        };

        ApplyToken(token);
        StartTimers(heartbeatMin);

        _log.Information("Windows session started. User={User}", Environment.UserName);
        StatusMessage?.Invoke(this, $"✔ Sesión Windows · {Environment.UserName}");
        return _session;
    }

    public async Task LogoffAsync(CancellationToken ct = default)
    {
        StopTimers();
        if (_session?.IsActive != true) return;

        _log.Information("Logging off. User={User}", _session.Username);

        try { await _http.PostAsync($"{_session.PvwaUrl}/API/Auth/Logoff", null, ct); }
        catch (Exception ex) { _log.Warning(ex, "Logoff API call failed (ignored)"); }

        _session.Invalidate();
        ClearSecurePassword();
        _http.DefaultRequestHeaders.Remove("Authorization");
        StatusMessage?.Invoke(this, "✔ Sesión cerrada");
        _log.Information("Session closed");
    }

    // ── Timers ─────────────────────────────────────────────────────────────

    private void StartTimers(int heartbeatMinutes)
    {
        StopTimers();

        // Heartbeat timer
        _heartbeatTimer = new System.Timers.Timer(Math.Clamp(heartbeatMinutes, 1, 60) * 60_000);
        _heartbeatTimer.Elapsed += OnHeartbeat;
        _heartbeatTimer.AutoReset = true;
        _heartbeatTimer.Start();

        // Hard-expiry timer — fires once after HardSessionTimeoutHours
        _hardExpiryTimer = new System.Timers.Timer(HardSessionTimeoutHours * 3_600_000);
        _hardExpiryTimer.Elapsed += OnHardExpiry;
        _hardExpiryTimer.AutoReset = false;
        _hardExpiryTimer.Start();
    }

    private void StopTimers()
    {
        _heartbeatTimer?.Stop(); _heartbeatTimer?.Dispose(); _heartbeatTimer = null;
        _hardExpiryTimer?.Stop(); _hardExpiryTimer?.Dispose(); _hardExpiryTimer = null;
    }

    private async void OnHeartbeat(object? _, ElapsedEventArgs __)
    {
        if (_session?.IsActive != true) return;

        // Enforce hard expiry even if the timer misfires
        if (DateTime.Now >= _session.HardExpiry)
        {
            _log.Warning("Hard session timeout reached during heartbeat. User={User}", _session.Username);
            await ExpireSessionAsync();
            return;
        }

        try
        {
            // Strategy 1 – ExtendSession (CyberArk v12+)
            var r = await _http.PostAsync($"{_session.PvwaUrl}/API/Auth/ExtendSession", null);
            if (r.IsSuccessStatusCode)
            {
                _session.LastRenew = DateTime.Now;
                _consecutiveFailures = 0;
                SessionRenewed?.Invoke(this, _session.Token);
                _log.Debug("Session extended via ExtendSession. User={User}", _session.Username);
                StatusMessage?.Invoke(this, $"🔄 Sesión extendida · {DateTime.Now:HH:mm:ss}");
                return;
            }

            // Strategy 2 – re-login with cached SecureString
            if (_securePassword is not null && _session.Username is not null)
            {
                var plainPwd = FromSecureString(_securePassword);
                try
                {
                    var token = await FetchTokenAsync(_session.PvwaUrl, _session.Username, plainPwd, _authMethod ?? "CyberArk");
                    _session.Token    = token;
                    _session.LastRenew = DateTime.Now;
                    _consecutiveFailures = 0;
                    ApplyToken(token);
                    SessionRenewed?.Invoke(this, token);
                    _log.Information("Token renewed via re-login. User={User}", _session.Username);
                    StatusMessage?.Invoke(this, $"🔄 Token renovado · {DateTime.Now:HH:mm:ss}");
                }
                finally
                {
                    // Zero out the temp plain string from stack/heap
                    plainPwd = null;
                }
            }
        }
        catch (Exception ex)
        {
            _consecutiveFailures++;
            _log.Warning(ex, "Heartbeat failed ({N}/{Max}). User={User}", _consecutiveFailures, MaxConsecutiveFailures, _session?.Username);
            StatusMessage?.Invoke(this, $"⚠ Keep-alive fallido ({_consecutiveFailures}/{MaxConsecutiveFailures})");

            if (_consecutiveFailures >= MaxConsecutiveFailures)
                await ExpireSessionAsync();
        }
    }

    private void OnHardExpiry(object? _, ElapsedEventArgs __)
    {
        _log.Warning("Hard session timeout fired. User={User}", _session?.Username);
        _ = ExpireSessionAsync();
    }

    private async Task ExpireSessionAsync()
    {
        StopTimers();
        _session?.Invalidate();
        ClearSecurePassword();
        _http.DefaultRequestHeaders.Remove("Authorization");
        SessionExpired?.Invoke(this, EventArgs.Empty);
        StatusMessage?.Invoke(this, "⚠ Sesión expirada. Por favor, inicia sesión de nuevo.");
        await Task.CompletedTask;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private async Task<string> FetchTokenAsync(
        string base_, string user, string pass, string method,
        CancellationToken ct = default)
    {
        var endpoint = method.ToUpperInvariant() switch
        {
            "LDAP"    => "LDAP",
            "RADIUS"  => "Radius",
            "WINDOWS" => "Windows",
            _         => "CyberArk"
        };
        var url  = $"{base_}/API/auth/{endpoint}/Logon";
        var body = JsonSerializer.Serialize(new LogonRequest { Username = user, Password = pass, ConcurrentSession = true });

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(HttpTimeout);

        var resp = await _http.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json"), cts.Token);
        await EnsureOk(resp, ct);
        var raw   = await resp.Content.ReadAsStringAsync(ct);
        var token = raw.Trim('"');
        if (string.IsNullOrWhiteSpace(token)) throw new InvalidOperationException("Token vacío recibido del servidor.");
        return token;
    }

    private void ApplyToken(string token)
    {
        _http.DefaultRequestHeaders.Remove("Authorization");
        _http.DefaultRequestHeaders.Add("Authorization", token);
    }

    // ── SecureString helpers ───────────────────────────────────────────────

    private static SecureString ToSecureString(string plain)
    {
        var ss = new SecureString();
        foreach (var c in plain) ss.AppendChar(c);
        ss.MakeReadOnly();
        return ss;
    }

    /// <summary>
    /// Converts SecureString to plain string only for the instant it is needed.
    /// Caller must ensure the resulting string is not stored and is eligible for GC ASAP.
    /// </summary>
    private static string FromSecureString(SecureString ss)
    {
        var ptr = IntPtr.Zero;
        try
        {
            ptr = Marshal.SecureStringToGlobalAllocUnicode(ss);
            return Marshal.PtrToStringUni(ptr) ?? string.Empty;
        }
        finally
        {
            if (ptr != IntPtr.Zero) Marshal.ZeroFreeGlobalAllocUnicode(ptr);
        }
    }

    private void ClearSecurePassword()
    {
        _securePassword?.Dispose();
        _securePassword = null;
    }

    // ── HTTP error handling ────────────────────────────────────────────────

    private static async Task EnsureOk(HttpResponseMessage r, CancellationToken ct = default)
    {
        if (r.IsSuccessStatusCode) return;
        var body = await r.Content.ReadAsStringAsync(ct);
        throw new InvalidOperationException(ParseError((int)r.StatusCode, body));
    }

    private static string ParseError(int code, string body)
    {
        var prefix = code switch { 401 => "No autorizado", 403 => "Acceso denegado", 404 => "No encontrado", 409 => "Conflicto", _ => $"HTTP {code}" };
        try { using var d = JsonDocument.Parse(body); if (d.RootElement.TryGetProperty("ErrorMessage", out var m)) return $"{prefix}: {m.GetString()}"; } catch { }
        return $"{prefix}: {(body.Length > 200 ? body[..200] : body)}";
    }

    private static string NormalizeUrl(string url)
    {
        url = url.TrimEnd('/');
        if (!url.Contains("/PasswordVault", StringComparison.OrdinalIgnoreCase))
            url += "/PasswordVault";
        return url;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        StopTimers();
        ClearSecurePassword();
    }

    // ── DTOs ───────────────────────────────────────────────────────────────

    private class LogonRequest
    {
        [JsonPropertyName("username")]          public string Username { get; set; } = string.Empty;
        [JsonPropertyName("password")]          public string Password { get; set; } = string.Empty;
        [JsonPropertyName("concurrentSession")] public bool ConcurrentSession { get; set; }
    }
}

    public event EventHandler<string>? StatusMessage;
    public event EventHandler<string>? SessionRenewed;
    public event EventHandler?         SessionExpired;

    private readonly HttpClient _http;
    private System.Timers.Timer? _timer;
    private UserSession? _session;
    private string? _cachedPassword;
    private int _consecutiveFailures;
    private bool _disposed;

    public AuthService(HttpClient http) => _http = http;

    public UserSession? CurrentSession => _session?.IsActive == true ? _session : null;

    // ── Auth Methods ─────────────────────────────────────────────────────────

    /// <summary>Login CyberArk native, LDAP, RADIUS o Windows.</summary>
    public async Task<UserSession> LoginAsync(string pvwaUrl, string username, string password,
        string authMethod = "CyberArk", int heartbeatMin = 10, CancellationToken ct = default)
    {
        _cachedPassword = password;
        _consecutiveFailures = 0;
        var base_ = NormalizeUrl(pvwaUrl);
        var token  = await FetchTokenAsync(base_, username, password, authMethod, ct);

        _session = new UserSession
        {
            Token    = token,
            Username = username,
            PvwaUrl  = base_,
            LoginTime = DateTime.Now,
            LastRenew = DateTime.Now
        };
        ApplyToken(token);
        StartHeartbeat(heartbeatMin);
        StatusMessage?.Invoke(this, $"✔ Sesión iniciada · {username} · keep-alive cada {heartbeatMin} min");
        return _session;
    }

    /// <summary>Windows Integrated Auth (no password needed).</summary>
    public async Task<UserSession> LoginWindowsAsync(string pvwaUrl, int heartbeatMin = 10, CancellationToken ct = default)
    {
        var base_ = NormalizeUrl(pvwaUrl);
        var url   = $"{base_}/API/auth/Windows/Logon";
        var resp  = await _http.PostAsync(url, null, ct);
        await EnsureOk(resp, ct);
        var token = (await resp.Content.ReadAsStringAsync(ct)).Trim('"');

        _session = new UserSession { Token = token, Username = Environment.UserName, PvwaUrl = base_, LoginTime = DateTime.Now, LastRenew = DateTime.Now };
        ApplyToken(token);
        StartHeartbeat(heartbeatMin);
        StatusMessage?.Invoke(this, $"✔ Sesión Windows · {Environment.UserName}");
        return _session;
    }

    public async Task LogoffAsync(CancellationToken ct = default)
    {
        StopHeartbeat();
        if (_session?.IsActive != true) return;
        try { await _http.PostAsync($"{_session.PvwaUrl}/API/Auth/Logoff", null, ct); } catch { }
        _session.Invalidate();
        _cachedPassword = null;
        _http.DefaultRequestHeaders.Remove("Authorization");
        StatusMessage?.Invoke(this, "✔ Sesión cerrada");
    }

    // ── Heartbeat ────────────────────────────────────────────────────────────

    private void StartHeartbeat(int minutes)
    {
        StopHeartbeat();
        _timer = new System.Timers.Timer(Math.Clamp(minutes, 1, 60) * 60_000);
        _timer.Elapsed += OnTick;
        _timer.AutoReset = true;
        _timer.Start();
    }

    private void StopHeartbeat() { _timer?.Stop(); _timer?.Dispose(); _timer = null; }

    private async void OnTick(object? _, ElapsedEventArgs __)
    {
        if (_session?.IsActive != true) return;
        try
        {
            // Strategy 1 – ExtendSession (CyberArk v12+)
            var r = await _http.PostAsync($"{_session.PvwaUrl}/API/Auth/ExtendSession", null);
            if (r.IsSuccessStatusCode)
            {
                _session.LastRenew = DateTime.Now;
                _consecutiveFailures = 0;
                SessionRenewed?.Invoke(this, _session.Token);
                StatusMessage?.Invoke(this, $"🔄 Sesión extendida · {DateTime.Now:HH:mm:ss}");
                return;
            }

            // Strategy 2 – re-login
            if (_cachedPassword is not null)
            {
                var token = await FetchTokenAsync(_session.PvwaUrl, _session.Username, _cachedPassword, "CyberArk");
                _session.Token    = token;
                _session.LastRenew = DateTime.Now;
                _consecutiveFailures = 0;
                ApplyToken(token);
                SessionRenewed?.Invoke(this, token);
                StatusMessage?.Invoke(this, $"🔄 Token renovado · {DateTime.Now:HH:mm:ss}");
            }
        }
        catch
        {
            _consecutiveFailures++;
            StatusMessage?.Invoke(this, $"⚠ Keep-alive fallido ({_consecutiveFailures}/3)");
            if (_consecutiveFailures >= 3) { StopHeartbeat(); SessionExpired?.Invoke(this, EventArgs.Empty); }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private async Task<string> FetchTokenAsync(string base_, string user, string pass, string method, CancellationToken ct = default)
    {
        // Endpoint varies by auth method
        var endpoint = method.ToUpperInvariant() switch
        {
            "LDAP"    => "LDAP",
            "RADIUS"  => "Radius",
            "WINDOWS" => "Windows",
            _         => "CyberArk"
        };
        var url  = $"{base_}/API/auth/{endpoint}/Logon";
        var body = JsonSerializer.Serialize(new LogonRequest { Username = user, Password = pass, ConcurrentSession = true });
        var resp = await _http.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json"), ct);
        await EnsureOk(resp, ct);
        var raw = await resp.Content.ReadAsStringAsync(ct);
        var token = raw.Trim('"');
        if (string.IsNullOrWhiteSpace(token)) throw new InvalidOperationException("Token vacío recibido del servidor.");
        return token;
    }

    private void ApplyToken(string token)
    {
        _http.DefaultRequestHeaders.Remove("Authorization");
        _http.DefaultRequestHeaders.Add("Authorization", token);
    }

    private static async Task EnsureOk(HttpResponseMessage r, CancellationToken ct = default)
    {
        if (r.IsSuccessStatusCode) return;
        var body = await r.Content.ReadAsStringAsync(ct);
        throw new InvalidOperationException(ParseError((int)r.StatusCode, body));
    }

    private static string ParseError(int code, string body)
    {
        var prefix = code switch { 401 => "No autorizado", 403 => "Acceso denegado", 404 => "No encontrado", 409 => "Conflicto", _ => $"HTTP {code}" };
        try { using var d = JsonDocument.Parse(body); if (d.RootElement.TryGetProperty("ErrorMessage", out var m)) return $"{prefix}: {m.GetString()}"; } catch { }
        return $"{prefix}: {(body.Length > 200 ? body[..200] : body)}";
    }

    private static string NormalizeUrl(string url)
    {
        url = url.TrimEnd('/');
        if (!url.Contains("/PasswordVault", StringComparison.OrdinalIgnoreCase))
            url += "/PasswordVault";
        return url;
    }

    public void Dispose() { if (_disposed) return; _disposed = true; StopHeartbeat(); }

    private class LogonRequest
    {
        [JsonPropertyName("username")]          public string Username { get; set; } = string.Empty;
        [JsonPropertyName("password")]          public string Password { get; set; } = string.Empty;
        [JsonPropertyName("concurrentSession")] public bool ConcurrentSession { get; set; }
    }
}
