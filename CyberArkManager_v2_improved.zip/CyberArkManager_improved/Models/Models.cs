using System.Text.Json.Serialization;

namespace CyberArkManager.Models;

// ════════════════════════════════════════════════════════════════════════════
// SESSION / CONFIG
// ════════════════════════════════════════════════════════════════════════════

public class UserSession
{
    public string Token        { get; set; } = string.Empty;
    public string Username     { get; set; } = string.Empty;
    public string PvwaUrl      { get; set; } = string.Empty;
    public DateTime LoginTime  { get; set; }
    public DateTime LastRenew  { get; set; }
    /// <summary>Absolute session ceiling — session must be invalidated after this regardless of heartbeat.</summary>
    public DateTime HardExpiry { get; set; }
    public bool IsActive       => !string.IsNullOrEmpty(Token) && DateTime.Now < HardExpiry;
    public TimeSpan Duration   => DateTime.Now - LoginTime;
    public string DurationDisplay
    {
        get { var d = Duration; return d.TotalHours >= 1 ? $"{(int)d.TotalHours}h {d.Minutes}m" : $"{d.Minutes}m {d.Seconds}s"; }
    }
    public void Invalidate() => Token = string.Empty;
}

public class AppConfiguration
{
    public string  PvwaUrl                  { get; set; } = string.Empty;
    public string? LastUsername             { get; set; }
    public bool    RememberUsername         { get; set; } = true;
    public bool    AcceptAllCertificates    { get; set; } = false;
    public int     HeartbeatIntervalMinutes { get; set; } = 10;
    public string  AuthMethod              { get; set; } = "CyberArk";
    public string  Theme                   { get; set; } = "Dark";
}

// ════════════════════════════════════════════════════════════════════════════
// ACCOUNTS
// ════════════════════════════════════════════════════════════════════════════

public class Account
{
    [JsonPropertyName("id")]                   public string Id { get; set; } = string.Empty;
    [JsonPropertyName("name")]                 public string Name { get; set; } = string.Empty;
    [JsonPropertyName("address")]              public string Address { get; set; } = string.Empty;
    [JsonPropertyName("userName")]             public string UserName { get; set; } = string.Empty;
    [JsonPropertyName("platformId")]           public string PlatformId { get; set; } = string.Empty;
    [JsonPropertyName("safeName")]             public string SafeName { get; set; } = string.Empty;
    [JsonPropertyName("secretType")]           public string SecretType { get; set; } = string.Empty;
    [JsonPropertyName("createdTime")]          public long CreatedTime { get; set; }
    [JsonPropertyName("categoryModificationTime")] public long CategoryModificationTime { get; set; }
    [JsonPropertyName("secretManagement")]     public SecretManagement? SecretManagement { get; set; }
    [JsonPropertyName("remoteMachinesAccess")] public RemoteMachinesAccess? RemoteMachinesAccess { get; set; }

    public string CreatedDisplay   => CreatedTime > 0 ? DateTimeOffset.FromUnixTimeSeconds(CreatedTime).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
    public string ModifiedDisplay  => CategoryModificationTime > 0 ? DateTimeOffset.FromUnixTimeSeconds(CategoryModificationTime).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
    public string CpmStatus        => SecretManagement?.Status ?? "Unknown";
    public bool   AutoManaged      => SecretManagement?.AutomaticManagementEnabled ?? false;
}

public class SecretManagement
{
    [JsonPropertyName("automaticManagementEnabled")] public bool AutomaticManagementEnabled { get; set; }
    [JsonPropertyName("manualManagementReason")]     public string? ManualManagementReason { get; set; }
    [JsonPropertyName("status")]                     public string Status { get; set; } = string.Empty;
    [JsonPropertyName("lastModifiedTime")]           public long LastModifiedTime { get; set; }
    [JsonPropertyName("lastReconciledTime")]         public long LastReconciledTime { get; set; }
    [JsonPropertyName("lastVerifiedTime")]           public long LastVerifiedTime { get; set; }
}

public class RemoteMachinesAccess
{
    [JsonPropertyName("remoteMachines")]                      public string? RemoteMachines { get; set; }
    [JsonPropertyName("accessRestrictedToRemoteMachines")]    public bool AccessRestrictedToRemoteMachines { get; set; }
}

public class AccountsResponse
{
    [JsonPropertyName("value")]    public List<Account> Value { get; set; } = new();
    [JsonPropertyName("count")]    public int Count { get; set; }
    [JsonPropertyName("nextLink")] public string? NextLink { get; set; }
}

public class AccountCreateRequest
{
    [JsonPropertyName("name")]             public string? Name { get; set; }
    [JsonPropertyName("address")]          public string Address { get; set; } = string.Empty;
    [JsonPropertyName("userName")]         public string UserName { get; set; } = string.Empty;
    [JsonPropertyName("platformId")]       public string PlatformId { get; set; } = string.Empty;
    [JsonPropertyName("safeName")]         public string SafeName { get; set; } = string.Empty;
    [JsonPropertyName("secret")]           public string? Secret { get; set; }
    [JsonPropertyName("secretType")]       public string SecretType { get; set; } = "password";
    [JsonPropertyName("secretManagement")] public SecretManagementRequest? SecretManagement { get; set; }
    [JsonPropertyName("platformAccountProperties")] public Dictionary<string, string>? PlatformAccountProperties { get; set; }
}

public class SecretManagementRequest
{
    [JsonPropertyName("automaticManagementEnabled")] public bool AutomaticManagementEnabled { get; set; } = true;
    [JsonPropertyName("manualManagementReason")]     public string? ManualManagementReason { get; set; }
}

public class PatchOperation
{
    [JsonPropertyName("op")]    public string Op    { get; set; } = "replace";
    [JsonPropertyName("path")]  public string Path  { get; set; } = string.Empty;
    [JsonPropertyName("value")] public object Value { get; set; } = string.Empty;
}

public class AccountActivityLog
{
    [JsonPropertyName("Action")]   public string Action  { get; set; } = string.Empty;
    [JsonPropertyName("Time")]     public long Time      { get; set; }
    [JsonPropertyName("User")]     public string User    { get; set; } = string.Empty;
    [JsonPropertyName("Reason")]   public string? Reason { get; set; }
    public string TimeDisplay => Time > 0 ? DateTimeOffset.FromUnixTimeSeconds(Time).LocalDateTime.ToString("dd/MM/yyyy HH:mm:ss") : "—";
}

// ════════════════════════════════════════════════════════════════════════════
// SAFES
// ════════════════════════════════════════════════════════════════════════════

public class Safe
{
    [JsonPropertyName("safeUrlId")]              public string SafeUrlId   { get; set; } = string.Empty;
    [JsonPropertyName("safeName")]               public string SafeName    { get; set; } = string.Empty;
    [JsonPropertyName("safeNumber")]             public int    SafeNumber  { get; set; }
    [JsonPropertyName("description")]            public string Description { get; set; } = string.Empty;
    [JsonPropertyName("location")]               public string Location    { get; set; } = string.Empty;
    [JsonPropertyName("managingCPM")]            public string ManagingCPM { get; set; } = string.Empty;
    [JsonPropertyName("numberOfVersionsRetention")] public int NumberOfVersionsRetention { get; set; }
    [JsonPropertyName("numberOfDaysRetention")]  public int NumberOfDaysRetention  { get; set; }
    [JsonPropertyName("autoPurgeEnabled")]       public bool AutoPurgeEnabled      { get; set; }
    [JsonPropertyName("olacEnabled")]            public bool OlacEnabled           { get; set; }
    [JsonPropertyName("creationTime")]           public long CreationTime          { get; set; }
    [JsonPropertyName("creator")]                public SafeCreator? Creator       { get; set; }
    public string CreationDisplay => CreationTime > 0 ? DateTimeOffset.FromUnixTimeSeconds(CreationTime).LocalDateTime.ToString("dd/MM/yyyy") : "—";
    public override string ToString() => SafeName;
}

public class SafeCreator
{
    [JsonPropertyName("id")]   public string Id   { get; set; } = string.Empty;
    [JsonPropertyName("name")] public string Name { get; set; } = string.Empty;
}

public class SafesResponse
{
    [JsonPropertyName("value")]    public List<Safe> Value  { get; set; } = new();
    [JsonPropertyName("count")]    public int        Count  { get; set; }
    [JsonPropertyName("nextLink")] public string?    NextLink { get; set; }
}

public class SafeCreateRequest
{
    [JsonPropertyName("safeName")]                  public string SafeName    { get; set; } = string.Empty;
    [JsonPropertyName("description")]               public string Description { get; set; } = string.Empty;
    [JsonPropertyName("location")]                  public string Location    { get; set; } = string.Empty;
    [JsonPropertyName("managingCPM")]               public string ManagingCPM { get; set; } = string.Empty;
    [JsonPropertyName("numberOfVersionsRetention")] public int NumberOfVersionsRetention { get; set; } = 5;
    [JsonPropertyName("numberOfDaysRetention")]     public int NumberOfDaysRetention     { get; set; } = 7;
    [JsonPropertyName("autoPurgeEnabled")]          public bool AutoPurgeEnabled         { get; set; } = false;
    [JsonPropertyName("olacEnabled")]               public bool OlacEnabled              { get; set; } = false;
}

public class SafeMember
{
    [JsonPropertyName("safeUrlId")]          public string SafeUrlId   { get; set; } = string.Empty;
    [JsonPropertyName("safeName")]           public string SafeName    { get; set; } = string.Empty;
    [JsonPropertyName("safeNumber")]         public int    SafeNumber  { get; set; }
    [JsonPropertyName("memberId")]           public string MemberId    { get; set; } = string.Empty;
    [JsonPropertyName("memberName")]         public string MemberName  { get; set; } = string.Empty;
    [JsonPropertyName("memberType")]         public string MemberType  { get; set; } = string.Empty;
    [JsonPropertyName("membershipExpirationDate")] public long? MembershipExpirationDate { get; set; }
    [JsonPropertyName("isExpiredMembershipEnable")] public bool IsExpiredMembershipEnable { get; set; }
    [JsonPropertyName("isPredefinedUser")]   public bool IsPredefinedUser { get; set; }
    [JsonPropertyName("permissions")]        public SafePermissions? Permissions { get; set; }
    public string ExpirationDisplay => MembershipExpirationDate.HasValue
        ? DateTimeOffset.FromUnixTimeSeconds(MembershipExpirationDate.Value).LocalDateTime.ToString("dd/MM/yyyy") : "Sin expiración";
}

public class SafePermissions
{
    [JsonPropertyName("useAccounts")]                          public bool UseAccounts { get; set; }
    [JsonPropertyName("retrieveAccounts")]                     public bool RetrieveAccounts { get; set; }
    [JsonPropertyName("listAccounts")]                         public bool ListAccounts { get; set; }
    [JsonPropertyName("addAccounts")]                          public bool AddAccounts { get; set; }
    [JsonPropertyName("updateAccountContent")]                 public bool UpdateAccountContent { get; set; }
    [JsonPropertyName("updateAccountProperties")]              public bool UpdateAccountProperties { get; set; }
    [JsonPropertyName("initiateCPMAccountManagementOperations")] public bool InitiateCPMAccountManagementOperations { get; set; }
    [JsonPropertyName("specifyNextAccountContent")]            public bool SpecifyNextAccountContent { get; set; }
    [JsonPropertyName("renameAccounts")]                       public bool RenameAccounts { get; set; }
    [JsonPropertyName("deleteAccounts")]                       public bool DeleteAccounts { get; set; }
    [JsonPropertyName("unlockAccounts")]                       public bool UnlockAccounts { get; set; }
    [JsonPropertyName("manageSafe")]                           public bool ManageSafe { get; set; }
    [JsonPropertyName("manageSafeMembers")]                    public bool ManageSafeMembers { get; set; }
    [JsonPropertyName("backupSafe")]                           public bool BackupSafe { get; set; }
    [JsonPropertyName("viewAuditLog")]                         public bool ViewAuditLog { get; set; }
    [JsonPropertyName("viewSafeMembers")]                      public bool ViewSafeMembers { get; set; }
    [JsonPropertyName("accessWithoutConfirmation")]            public bool AccessWithoutConfirmation { get; set; }
    [JsonPropertyName("createFolders")]                        public bool CreateFolders { get; set; }
    [JsonPropertyName("deleteFolders")]                        public bool DeleteFolders { get; set; }
    [JsonPropertyName("moveAccountsAndFolders")]               public bool MoveAccountsAndFolders { get; set; }
    [JsonPropertyName("requestsAuthorizationLevel1")]          public bool RequestsAuthorizationLevel1 { get; set; }
    [JsonPropertyName("requestsAuthorizationLevel2")]          public bool RequestsAuthorizationLevel2 { get; set; }
}

public class SafeMembersResponse
{
    [JsonPropertyName("value")]    public List<SafeMember> Value  { get; set; } = new();
    [JsonPropertyName("count")]    public int Count               { get; set; }
    [JsonPropertyName("nextLink")] public string? NextLink        { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// USERS
// ════════════════════════════════════════════════════════════════════════════

public class CyberArkUser
{
    [JsonPropertyName("id")]                   public int    Id          { get; set; }
    [JsonPropertyName("username")]             public string Username    { get; set; } = string.Empty;
    [JsonPropertyName("source")]               public string Source      { get; set; } = string.Empty;
    [JsonPropertyName("userType")]             public string UserType    { get; set; } = string.Empty;
    [JsonPropertyName("componentUser")]        public bool   ComponentUser { get; set; }
    [JsonPropertyName("firstName")]            public string? FirstName  { get; set; }
    [JsonPropertyName("lastName")]             public string? LastName   { get; set; }
    [JsonPropertyName("email")]                public string? Email      { get; set; }
    [JsonPropertyName("location")]             public string? Location   { get; set; }
    [JsonPropertyName("suspended")]            public bool   Suspended   { get; set; }
    [JsonPropertyName("lastSuccessfulLoginDate")] public long LastSuccessfulLoginDate { get; set; }
    [JsonPropertyName("groups")]               public List<UserGroup>? Groups { get; set; }
    [JsonPropertyName("vaultAuthorization")]   public List<string>? VaultAuthorization { get; set; }
    public string FullName   => $"{FirstName} {LastName}".Trim();
    public string StatusText => Suspended ? "Suspendido" : "Activo";
    public string LastLogin  => LastSuccessfulLoginDate > 0
        ? DateTimeOffset.FromUnixTimeSeconds(LastSuccessfulLoginDate).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "Nunca";
}

public class UsersResponse
{
    [JsonPropertyName("Users")]    public List<CyberArkUser> Users  { get; set; } = new();
    [JsonPropertyName("Total")]    public int Total                  { get; set; }
    [JsonPropertyName("nextLink")] public string? NextLink           { get; set; }
}

public class UserCreateRequest
{
    [JsonPropertyName("username")]           public string Username    { get; set; } = string.Empty;
    [JsonPropertyName("userType")]           public string UserType    { get; set; } = "EPVUser";
    [JsonPropertyName("initialPassword")]    public string InitialPassword { get; set; } = string.Empty;
    [JsonPropertyName("authenticationMethod")] public List<string>? AuthenticationMethod { get; set; }
    [JsonPropertyName("location")]           public string Location    { get; set; } = "\\";
    [JsonPropertyName("firstName")]          public string? FirstName  { get; set; }
    [JsonPropertyName("lastName")]           public string? LastName   { get; set; }
    [JsonPropertyName("email")]              public string? Email      { get; set; }
    [JsonPropertyName("vaultAuthorization")] public List<string>? VaultAuthorization { get; set; }
}

public class UserGroup
{
    [JsonPropertyName("id")]          public int    Id          { get; set; }
    [JsonPropertyName("name")]        public string Name        { get; set; } = string.Empty;
    [JsonPropertyName("groupType")]   public string GroupType   { get; set; } = string.Empty;
    [JsonPropertyName("description")] public string Description { get; set; } = string.Empty;
    [JsonPropertyName("location")]    public string Location    { get; set; } = string.Empty;
    [JsonPropertyName("membersCount")] public int MembersCount  { get; set; }
}

public class GroupsResponse
{
    [JsonPropertyName("value")]    public List<UserGroup> Value  { get; set; } = new();
    [JsonPropertyName("count")]    public int Count               { get; set; }
    [JsonPropertyName("nextLink")] public string? NextLink        { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// PLATFORMS
// ════════════════════════════════════════════════════════════════════════════

public class Platform
{
    [JsonPropertyName("id")]                  public string Id          { get; set; } = string.Empty;
    [JsonPropertyName("name")]                public string Name        { get; set; } = string.Empty;
    [JsonPropertyName("systemType")]          public string SystemType  { get; set; } = string.Empty;
    [JsonPropertyName("active")]              public bool   Active      { get; set; }
    [JsonPropertyName("description")]         public string Description { get; set; } = string.Empty;
    [JsonPropertyName("platformBaseID")]      public string? PlatformBaseID { get; set; }
    [JsonPropertyName("platformType")]        public string PlatformType { get; set; } = string.Empty;
    [JsonPropertyName("allowedSafes")]        public string? AllowedSafes { get; set; }
    public string ActiveText => Active ? "Activa" : "Inactiva";
}

public class PlatformsResponse
{
    [JsonPropertyName("Platforms")] public List<PlatformWrapper> Platforms { get; set; } = new();
    [JsonPropertyName("Total")]     public int Total                        { get; set; }
    [JsonPropertyName("nextLink")]  public string? NextLink                 { get; set; }
}

public class PlatformWrapper
{
    [JsonPropertyName("general")]   public Platform? General { get; set; }
    [JsonPropertyName("properties")] public PlatformProperties? Properties { get; set; }
}

public class PlatformProperties
{
    [JsonPropertyName("required")]  public List<PlatformProperty>? Required  { get; set; }
    [JsonPropertyName("optional")]  public List<PlatformProperty>? Optional  { get; set; }
}

public class PlatformProperty
{
    [JsonPropertyName("name")]          public string Name         { get; set; } = string.Empty;
    [JsonPropertyName("displayName")]   public string DisplayName  { get; set; } = string.Empty;
    [JsonPropertyName("type")]          public string Type         { get; set; } = string.Empty;
}

// ════════════════════════════════════════════════════════════════════════════
// PSM SESSIONS
// ════════════════════════════════════════════════════════════════════════════

public class PsmSession
{
    [JsonPropertyName("SessionID")]          public string SessionID   { get; set; } = string.Empty;
    [JsonPropertyName("User")]               public string User        { get; set; } = string.Empty;
    [JsonPropertyName("RemoteMachine")]      public string RemoteMachine { get; set; } = string.Empty;
    [JsonPropertyName("Start")]              public long Start         { get; set; }
    [JsonPropertyName("End")]                public long End           { get; set; }
    [JsonPropertyName("Duration")]           public long Duration      { get; set; }
    [JsonPropertyName("Status")]             public string Status      { get; set; } = string.Empty;
    [JsonPropertyName("AccountID")]          public string? AccountID  { get; set; }
    [JsonPropertyName("AccountName")]        public string? AccountName { get; set; }
    [JsonPropertyName("AccountAddress")]     public string? AccountAddress { get; set; }
    [JsonPropertyName("AccountPlatformID")]  public string? AccountPlatformID { get; set; }
    [JsonPropertyName("ConnectionComponent")] public string? ConnectionComponent { get; set; }
    [JsonPropertyName("Protocol")]           public string? Protocol   { get; set; }
    [JsonPropertyName("RiskScore")]          public int? RiskScore     { get; set; }
    public string StartDisplay => Start > 0 ? DateTimeOffset.FromUnixTimeSeconds(Start).LocalDateTime.ToString("dd/MM/yyyy HH:mm:ss") : "—";
    public string EndDisplay   => End > 0   ? DateTimeOffset.FromUnixTimeSeconds(End).LocalDateTime.ToString("dd/MM/yyyy HH:mm:ss")   : "Activa";
    public string DurationDisplay => Duration > 0 ? TimeSpan.FromSeconds(Duration).ToString(@"hh\:mm\:ss") : "—";
    public bool IsActive => Status.Equals("Active", StringComparison.OrdinalIgnoreCase);
}

public class PsmSessionsResponse
{
    [JsonPropertyName("Activities")] public List<PsmSession>? Activities { get; set; }
    [JsonPropertyName("Total")]      public int Total                     { get; set; }
    [JsonPropertyName("nextLink")]   public string? NextLink              { get; set; }
}

public class PsmRecording
{
    [JsonPropertyName("SessionID")]     public string SessionID     { get; set; } = string.Empty;
    [JsonPropertyName("SafeName")]      public string SafeName      { get; set; } = string.Empty;
    [JsonPropertyName("FolderName")]    public string FolderName    { get; set; } = string.Empty;
    [JsonPropertyName("FileName")]      public string FileName      { get; set; } = string.Empty;
    [JsonPropertyName("User")]          public string User          { get; set; } = string.Empty;
    [JsonPropertyName("RemoteMachine")] public string RemoteMachine { get; set; } = string.Empty;
    [JsonPropertyName("Start")]         public long Start           { get; set; }
    [JsonPropertyName("End")]           public long End             { get; set; }
    [JsonPropertyName("Duration")]      public long Duration        { get; set; }
    public string StartDisplay    => Start > 0    ? DateTimeOffset.FromUnixTimeSeconds(Start).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
    public string DurationDisplay => Duration > 0 ? TimeSpan.FromSeconds(Duration).ToString(@"hh\:mm\:ss") : "—";
}

public class PsmRecordingsResponse
{
    [JsonPropertyName("Recordings")] public List<PsmRecording>? Recordings { get; set; }
    [JsonPropertyName("Total")]      public int Total                       { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// APPLICATIONS
// ════════════════════════════════════════════════════════════════════════════

public class CyberArkApplication
{
    [JsonPropertyName("AppID")]         public string AppID       { get; set; } = string.Empty;
    [JsonPropertyName("Description")]   public string Description { get; set; } = string.Empty;
    [JsonPropertyName("Location")]      public string Location    { get; set; } = string.Empty;
    [JsonPropertyName("AccessPermittedFrom")] public int AccessPermittedFrom { get; set; }
    [JsonPropertyName("AccessPermittedTo")]   public int AccessPermittedTo   { get; set; }
    [JsonPropertyName("ExpirationDate")]      public string? ExpirationDate  { get; set; }
    [JsonPropertyName("Disabled")]            public bool Disabled           { get; set; }
    [JsonPropertyName("BusinessOwnerFName")]  public string? BusinessOwnerFName { get; set; }
    [JsonPropertyName("BusinessOwnerLName")]  public string? BusinessOwnerLName { get; set; }
    [JsonPropertyName("BusinessOwnerEmail")]  public string? BusinessOwnerEmail { get; set; }
    public string StatusText => Disabled ? "Deshabilitada" : "Activa";
    public string OwnerName  => $"{BusinessOwnerFName} {BusinessOwnerLName}".Trim();
}

public class ApplicationsResponse
{
    [JsonPropertyName("application")] public List<CyberArkApplication>? Application { get; set; }
}

public class AppAuthMethod
{
    [JsonPropertyName("authType")]   public string AuthType { get; set; } = string.Empty;
    [JsonPropertyName("authValue")]  public string AuthValue { get; set; } = string.Empty;
    [JsonPropertyName("IsFolder")]   public bool? IsFolder  { get; set; }
    [JsonPropertyName("Comment")]    public string? Comment { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// DISCOVERED ACCOUNTS
// ════════════════════════════════════════════════════════════════════════════

public class DiscoveredAccount
{
    [JsonPropertyName("id")]                    public string Id            { get; set; } = string.Empty;
    [JsonPropertyName("computerName")]          public string ComputerName  { get; set; } = string.Empty;
    [JsonPropertyName("userName")]              public string UserName      { get; set; } = string.Empty;
    [JsonPropertyName("accountType")]           public string AccountType   { get; set; } = string.Empty;
    [JsonPropertyName("discoveryDate")]         public long DiscoveryDate   { get; set; }
    [JsonPropertyName("lastLogonDate")]         public long LastLogonDate   { get; set; }
    [JsonPropertyName("osVersion")]             public string? OsVersion    { get; set; }
    [JsonPropertyName("platformType")]          public string? PlatformType { get; set; }
    [JsonPropertyName("privileged")]            public bool Privileged      { get; set; }
    [JsonPropertyName("dependencies")]          public int? Dependencies    { get; set; }
    public string DiscoveryDisplay => DiscoveryDate > 0 ? DateTimeOffset.FromUnixTimeSeconds(DiscoveryDate).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
    public string LastLogonDisplay  => LastLogonDate  > 0 ? DateTimeOffset.FromUnixTimeSeconds(LastLogonDate).LocalDateTime.ToString("dd/MM/yyyy") : "—";
}

public class DiscoveredAccountsResponse
{
    [JsonPropertyName("value")]    public List<DiscoveredAccount> Value { get; set; } = new();
    [JsonPropertyName("count")]    public int Count                      { get; set; }
    [JsonPropertyName("nextLink")] public string? NextLink               { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// SYSTEM HEALTH
// ════════════════════════════════════════════════════════════════════════════

public class SystemHealthComponent
{
    [JsonPropertyName("ComponentID")]     public string ComponentID   { get; set; } = string.Empty;
    [JsonPropertyName("ComponentName")]   public string ComponentName { get; set; } = string.Empty;
    [JsonPropertyName("ComponentVersion")] public string? ComponentVersion { get; set; }
    [JsonPropertyName("Instances")]       public List<ComponentInstance>? Instances { get; set; }
}

public class ComponentInstance
{
    [JsonPropertyName("ComponentUserName")] public string? ComponentUserName { get; set; }
    [JsonPropertyName("IP")]                public string? IP                 { get; set; }
    [JsonPropertyName("IsLoggedOn")]        public bool IsLoggedOn            { get; set; }
    [JsonPropertyName("LastLogonDate")]     public long? LastLogonDate        { get; set; }
    [JsonPropertyName("Connected")]         public bool Connected             { get; set; }
    public string StatusText => Connected ? "✅ Conectado" : "❌ Desconectado";
    public string LastLogon  => LastLogonDate.HasValue
        ? DateTimeOffset.FromUnixTimeSeconds(LastLogonDate.Value).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
}

public class SystemHealthResponse
{
    [JsonPropertyName("Components")] public List<SystemHealthComponent>? Components { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// ACCESS REQUESTS (Dual Control)
// ════════════════════════════════════════════════════════════════════════════

public class AccessRequest
{
    [JsonPropertyName("RequestID")]       public string RequestID      { get; set; } = string.Empty;
    [JsonPropertyName("SafeName")]        public string SafeName       { get; set; } = string.Empty;
    [JsonPropertyName("RequestorUserName")] public string RequestorUserName { get; set; } = string.Empty;
    [JsonPropertyName("RequestorReason")] public string? RequestorReason   { get; set; }
    [JsonPropertyName("Operation")]       public string Operation      { get; set; } = string.Empty;
    [JsonPropertyName("StatusTitle")]     public string StatusTitle    { get; set; } = string.Empty;
    [JsonPropertyName("ExpirationDate")]  public long ExpirationDate   { get; set; }
    [JsonPropertyName("AccountID")]       public string AccountID      { get; set; } = string.Empty;
    public string ExpirationDisplay => ExpirationDate > 0
        ? DateTimeOffset.FromUnixTimeSeconds(ExpirationDate).LocalDateTime.ToString("dd/MM/yyyy HH:mm") : "—";
}

public class AccessRequestsResponse
{
    [JsonPropertyName("GetSafesWithConfirmationResponse")] public List<AccessRequest>? GetSafesWithConfirmationResponse { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// CSV ROW (Bulk Load)
// ════════════════════════════════════════════════════════════════════════════

public class CsvAccountRow
{
    public string SafeName          { get; set; } = string.Empty;
    public string PlatformId        { get; set; } = string.Empty;
    public string Address           { get; set; } = string.Empty;
    public string UserName          { get; set; } = string.Empty;
    public string? Password         { get; set; }
    public string? Description      { get; set; }
    public bool   AutoManagement    { get; set; } = true;
    public string? ManualReason     { get; set; }
    public string? GroupName        { get; set; }
    public string? GroupPlatformId  { get; set; }
    public string? RemoteMachines   { get; set; }
    public string StatusText        { get; set; } = "—";
    public string StatusColor       { get; set; } = "#888888";
}

// ════════════════════════════════════════════════════════════════════════════
// COMMON
// ════════════════════════════════════════════════════════════════════════════

public class BulkUploadResult
{
    public int          Total     { get; set; }
    public int          Succeeded { get; set; }
    public int          Failed    { get; set; }
    public List<string> Errors    { get; set; } = new();
    public bool HasErrors => Failed > 0;
}

public class BulkUploadProgress
{
    public int    Current         { get; set; }
    public int    Total           { get; set; }
    public string AccountLabel    { get; set; } = string.Empty;
    public bool   Success         { get; set; }
    public string? ErrorMessage   { get; set; }
    public double Percent         => Total == 0 ? 0 : (double)Current / Total * 100;
}
