using System.IO;
using System.Net.Http;
using System.Windows;
using CyberArkManager.Helpers;
using CyberArkManager.Services;
using CyberArkManager.ViewModels;
using CyberArkManager.Views;
using Serilog;
using Serilog.Formatting.Compact;

namespace CyberArkManager;

public partial class App : Application
{
    MainViewModel? _vm;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // ── Bootstrap Serilog ────────────────────────────────────────────
        // Logs go to %AppData%\CyberArkManager\logs\cam-.log (rolling daily, keep 30 days).
        // Compact JSON format enables easy ingestion by SIEM / log aggregators.
        var logDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "CyberArkManager", "logs");

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .Enrich.WithProperty("App", "CyberArkManager")
            .Enrich.WithProperty("Version", "2.0")
            .WriteTo.File(
                formatter: new CompactJsonFormatter(),
                path: Path.Combine(logDir, "cam-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 30,
                shared: true)
            .WriteTo.Debug()
            .CreateLogger();

        Log.Information("Application starting");

        // ── Load configuration (DPAPI) ───────────────────────────────────
        AppConfiguration cfg;
        try
        {
            cfg = DpapiConfig.Load();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Failed to load DPAPI config — using defaults");
            cfg = new AppConfiguration();          // safe fallback, never crash on startup
        }

        // ── HttpClient setup ─────────────────────────────────────────────
        var handler = new HttpClientHandler();
        if (cfg.AcceptAllCertificates)
        {
            Log.Warning("TLS certificate validation is DISABLED — use only in lab environments");
            handler.ServerCertificateCustomValidationCallback =
                HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
        }

        // Outer HttpClient timeout is the hard ceiling; per-request timeouts
        // are enforced by CyberArkApiService via linked CancellationTokenSource.
        var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(90) };
        http.DefaultRequestHeaders.Add("User-Agent", "CyberArkManager/2.0 (.NET8)");

        var auth = new AuthService(http);
        var api  = new CyberArkApiService(http, auth);
        var csv  = new CsvService();

        _vm = new MainViewModel(auth, api, csv);
        _vm.Init(cfg);

        new MainWindow { DataContext = _vm }.Show();
        Log.Information("Application started");
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _vm?.Dispose();
        Log.Information("Application exiting");
        Log.CloseAndFlush();
        base.OnExit(e);
    }
}

    MainViewModel? _vm;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var cfg     = DpapiConfig.Load();
        var handler = new HttpClientHandler();
        if (cfg.AcceptAllCertificates)
            handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;

        var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(60) };
        http.DefaultRequestHeaders.Add("User-Agent", "CyberArkManager/2.0 (.NET8)");

        var auth = new AuthService(http);
        var api  = new CyberArkApiService(http, auth);
        var csv  = new CsvService();

        _vm = new MainViewModel(auth, api, csv);
        _vm.Init(cfg);

        new MainWindow { DataContext = _vm }.Show();
    }

    protected override void OnExit(ExitEventArgs e) { _vm?.Dispose(); base.OnExit(e); }
}
