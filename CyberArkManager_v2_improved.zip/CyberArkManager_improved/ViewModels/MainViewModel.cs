using System.Timers;
using System.Windows;
using CyberArkManager.Helpers;
using CyberArkManager.Models;
using CyberArkManager.Services;

namespace CyberArkManager.ViewModels;

public enum AppView
{
    Login, CsvGenerator, Accounts, Safes, Users,
    Platforms, PsmSessions, PsmRecordings,
    Applications, DiscoveredAccounts, SystemHealth, AccessRequests
}

public class MainViewModel : BaseViewModel, IDisposable
{
    readonly AuthService       _auth;
    readonly CyberArkApiService _api;
    readonly CsvService         _csv;
    System.Timers.Timer?       _clock;

    public MainViewModel(AuthService auth, CyberArkApiService api, CsvService csv)
    {
        _auth = auth; _api = api; _csv = csv;

        _auth.StatusMessage += (_, m) => Ui(() => SetStatus(m));
        _auth.SessionRenewed += (_, _) => Ui(RefreshSession);
        _auth.SessionExpired += (_, _) => Ui(() => { SetStatus("⚠ Sesión expirada.", true); ForceLogoff(); });

        LogoffCommand  = new AsyncRelayCommand(LogoffAsync, () => IsAuth);
        NavCommand     = new RelayCommand(o => Navigate(o?.ToString() ?? ""));

        StartClock();
        CurrentView = AppView.Login;
    }

    // ── Child VMs (created after login) ──────────────────────────────────────

    public LoginViewModel?             LoginVM      { get; private set; }
    public AccountsViewModel?          AccountsVM   { get; private set; }
    public SafesViewModel?             SafesVM      { get; private set; }
    public UsersViewModel?             UsersVM      { get; private set; }
    public PlatformsViewModel?         PlatformsVM  { get; private set; }
    public PsmSessionsViewModel?       PsmSessVM    { get; private set; }
    public PsmRecordingsViewModel?     PsmRecVM     { get; private set; }
    public ApplicationsViewModel?      AppsVM       { get; private set; }
    public DiscoveredAccountsViewModel? DiscovVM    { get; private set; }
    public SystemHealthViewModel?      HealthVM     { get; private set; }
    public AccessRequestsViewModel?    RequestsVM   { get; private set; }
    public CsvGeneratorViewModel?      CsvVM        { get; private set; }

    // ── Navigation ────────────────────────────────────────────────────────────

    AppView _view = AppView.Login;
    public AppView CurrentView { get => _view; set { Set(ref _view, value); NotifyNavProps(); } }

    public bool IsLoginView      => CurrentView == AppView.Login;
    public bool IsMainView       => CurrentView != AppView.Login;
    public bool IsAccountsView   => CurrentView == AppView.Accounts;
    public bool IsSafesView      => CurrentView == AppView.Safes;
    public bool IsUsersView      => CurrentView == AppView.Users;
    public bool IsPlatformsView  => CurrentView == AppView.Platforms;
    public bool IsPsmSessView    => CurrentView == AppView.PsmSessions;
    public bool IsPsmRecView     => CurrentView == AppView.PsmRecordings;
    public bool IsAppsView       => CurrentView == AppView.Applications;
    public bool IsDiscovView     => CurrentView == AppView.DiscoveredAccounts;
    public bool IsHealthView     => CurrentView == AppView.SystemHealth;
    public bool IsRequestsView   => CurrentView == AppView.AccessRequests;
    public bool IsCsvView        => CurrentView == AppView.CsvGenerator;

    void NotifyNavProps()
    {
        foreach (var p in new[] { nameof(IsLoginView), nameof(IsMainView),
            nameof(IsAccountsView), nameof(IsSafesView), nameof(IsUsersView),
            nameof(IsPlatformsView), nameof(IsPsmSessView), nameof(IsPsmRecView),
            nameof(IsAppsView), nameof(IsDiscovView), nameof(IsHealthView),
            nameof(IsRequestsView), nameof(IsCsvView) })
            OnPropertyChanged(p);
    }

    // ── Auth / Session ────────────────────────────────────────────────────────

    bool _isAuth; string _user = ""; string _sessionTime = ""; string _lastRenew = ""; string _clock_ = "";
    public bool   IsAuth        { get => _isAuth;       set { Set(ref _isAuth, value); OnPropertyChanged(nameof(IsLoginView)); OnPropertyChanged(nameof(IsMainView)); } }
    public string CurrentUser   { get => _user;         set => Set(ref _user, value); }
    public string SessionTime   { get => _sessionTime;  set => Set(ref _sessionTime, value); }
    public string LastRenewTime { get => _lastRenew;    set => Set(ref _lastRenew, value); }
    public string ClockTime     { get => _clock_;       set => Set(ref _clock_, value); }

    public AsyncRelayCommand LogoffCommand { get; }
    public RelayCommand      NavCommand    { get; }

    public void Init(AppConfiguration cfg)
    {
        LoginVM = new LoginViewModel(_auth, cfg);
        LoginVM.LoginSucceeded += OnLogin;
        OnPropertyChanged(nameof(LoginVM));
    }

    void OnLogin(object? _, UserSession s)
    {
        IsAuth      = true;
        CurrentUser = s.Username;

        AccountsVM  = new AccountsViewModel(_api);
        SafesVM     = new SafesViewModel(_api);
        UsersVM     = new UsersViewModel(_api);
        PlatformsVM = new PlatformsViewModel(_api);
        PsmSessVM   = new PsmSessionsViewModel(_api);
        PsmRecVM    = new PsmRecordingsViewModel(_api);
        AppsVM      = new ApplicationsViewModel(_api);
        DiscovVM    = new DiscoveredAccountsViewModel(_api);
        HealthVM    = new SystemHealthViewModel(_api);
        RequestsVM  = new AccessRequestsViewModel(_api);
        CsvVM       = new CsvGeneratorViewModel(_csv, _api);

        foreach (var n in new[] { nameof(AccountsVM), nameof(SafesVM), nameof(UsersVM),
            nameof(PlatformsVM), nameof(PsmSessVM), nameof(PsmRecVM), nameof(AppsVM),
            nameof(DiscovVM), nameof(HealthVM), nameof(RequestsVM), nameof(CsvVM) })
            OnPropertyChanged(n);

        Navigate("Accounts");
    }

    async Task LogoffAsync(object? _)
    {
        if (MessageBox.Show("¿Cerrar sesión?", "CyberArk Manager", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        IsBusy = true;
        await _auth.LogoffAsync();
        IsBusy = false;
        ForceLogoff();
    }

    void ForceLogoff()
    {
        IsAuth = false; CurrentUser = ""; SessionTime = ""; LastRenewTime = "";
        AccountsVM = null; SafesVM = null; UsersVM = null; PlatformsVM = null;
        PsmSessVM = null; PsmRecVM = null; AppsVM = null; DiscovVM = null;
        HealthVM = null; RequestsVM = null; CsvVM = null;
        foreach (var n in new[] { nameof(AccountsVM), nameof(SafesVM), nameof(UsersVM),
            nameof(PlatformsVM), nameof(PsmSessVM), nameof(PsmRecVM), nameof(AppsVM),
            nameof(DiscovVM), nameof(HealthVM), nameof(RequestsVM), nameof(CsvVM) })
            OnPropertyChanged(n);
        CurrentView = AppView.Login;
    }

    void Navigate(string viewName)
    {
        if (Enum.TryParse<AppView>(viewName, out var v)) CurrentView = v;
    }

    void RefreshSession()
    {
        var s = _auth.CurrentSession;
        if (s is null) return;
        SessionTime   = s.DurationDisplay;
        LastRenewTime = s.LastRenew.ToString("HH:mm:ss");
    }

    void StartClock()
    {
        _clock = new System.Timers.Timer(1000);
        _clock.Elapsed += (_, _) => Ui(() => { ClockTime = DateTime.Now.ToString("HH:mm:ss"); RefreshSession(); });
        _clock.Start();
    }

    public void Dispose() { _clock?.Dispose(); _auth.Dispose(); }
}
