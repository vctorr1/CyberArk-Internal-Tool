using CyberArkManager.Helpers;
using CyberArkManager.Models;
using CyberArkManager.Services;

namespace CyberArkManager.ViewModels;

public class LoginViewModel : BaseViewModel
{
    readonly AuthService    _auth;
    readonly AppConfiguration _cfg;

    public LoginViewModel(AuthService auth, AppConfiguration cfg)
    {
        _auth = auth; _cfg = cfg;
        PvwaUrl          = cfg.PvwaUrl;
        Username         = cfg.RememberUsername ? cfg.LastUsername ?? "" : "";
        RememberUsername = cfg.RememberUsername;
        SelectedAuthMethod = cfg.AuthMethod;
        HeartbeatMin     = cfg.HeartbeatIntervalMinutes;
        LoginCommand     = new AsyncRelayCommand(DoLoginAsync);
    }

    string _url = ""; string _user = ""; string _method = "CyberArk"; bool _remember = true; int _hb = 10;
    public string PvwaUrl            { get => _url;    set { Set(ref _url, value); } }
    public string Username           { get => _user;   set { Set(ref _user, value); } }
    public string Password           { get; set; } = "";
    public string SelectedAuthMethod { get => _method; set => Set(ref _method, value); }
    public bool   RememberUsername   { get => _remember; set => Set(ref _remember, value); }
    public int    HeartbeatMin       { get => _hb;    set => Set(ref _hb, Math.Clamp(value, 1, 60)); }

    public List<string> AuthMethods { get; } = new() { "CyberArk", "LDAP", "RADIUS", "Windows" };

    public AsyncRelayCommand LoginCommand { get; }
    public event EventHandler<UserSession>? LoginSucceeded;

    async Task DoLoginAsync(object? _)
    {
        if (string.IsNullOrWhiteSpace(PvwaUrl))  { SetStatus("⚠ URL del PVWA requerida.", true); return; }
        if (SelectedAuthMethod != "Windows" && string.IsNullOrWhiteSpace(Username)) { SetStatus("⚠ Usuario requerido.", true); return; }
        if (SelectedAuthMethod != "Windows" && string.IsNullOrWhiteSpace(Password)) { SetStatus("⚠ Contraseña requerida.", true); return; }

        IsBusy = true; SetStatus("🔄 Conectando...");
        try
        {
            UserSession session;
            if (SelectedAuthMethod == "Windows")
                session = await _auth.LoginWindowsAsync(PvwaUrl.Trim(), HeartbeatMin);
            else
                session = await _auth.LoginAsync(PvwaUrl.Trim(), Username.Trim(), Password, SelectedAuthMethod, HeartbeatMin);

            _cfg.PvwaUrl                 = PvwaUrl.Trim();
            _cfg.LastUsername            = RememberUsername ? Username.Trim() : null;
            _cfg.RememberUsername        = RememberUsername;
            _cfg.HeartbeatIntervalMinutes = HeartbeatMin;
            _cfg.AuthMethod              = SelectedAuthMethod;
            DpapiConfig.Save(_cfg);

            SetStatus($"✔ Sesión iniciada · {session.Username}");
            Password = "";
            LoginSucceeded?.Invoke(this, session);
        }
        catch (Exception ex) { SetStatus($"✖ {ex.Message}", true); }
        finally { IsBusy = false; }
    }
}
